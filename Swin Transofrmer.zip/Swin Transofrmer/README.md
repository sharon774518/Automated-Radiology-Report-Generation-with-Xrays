# 🩺 Automated Radiology Report Generation from Chest X-Rays Using Vision-Language Models

An end-to-end deep learning web application that automatically generates clinical radiology reports (Findings & Impression) from chest X-ray images using Vision-Language Models (VLMs).

---

## 📋 Topic Overview

Chest radiography is the most frequently performed diagnostic imaging examination worldwide. However, drafting comprehensive radiology reports requires substantial time from specialized radiologists, contributing to diagnostic delays and clinical fatigue.

This project implements an **automated radiology report generation system** utilizing a **Vision-Language Model (VLM)**. The model directly accepts chest radiographs, extracts multi-scale visual tokens, and autoregressively generates structured clinical text detailing normal anatomy, cardiopulmonary findings, and diagnostic impressions.

---

## 🧠 Model Architecture & Methodology

The system utilizes a multimodal encoder-decoder Vision-Language framework:

```
[ Chest X-Ray Image (224x224) ]
               │
               ▼
┌──────────────────────────────────────────────┐
│     Vision Encoder: Swin Transformer         │
│     (Hierarchical Multi-scale Features)      │
└──────────────────────────────────────────────┘
               │  Visual Embedding (1024-dim)
               ▼
┌──────────────────────────────────────────────┐
│     Multimodal Linear Projection Layer       │
│     (Maps visual tokens to text latent space)│
└──────────────────────────────────────────────┘
               │  Projected Tokens (768-dim)
               ▼
┌──────────────────────────────────────────────┐
│     Language Decoder: T5 Conditional Gen     │
│     (Autoregressive Beam Search Decoding)    │
└──────────────────────────────────────────────┘
               │
               ▼
[ Structured Radiology Report (Findings & Impression) ]
```

### 1. Vision Encoder (Swin Transformer)
- **Model:** `microsoft/swin-base-patch4-window7-224`
- Extracts hierarchical feature representations across shifted window self-attention stages, capturing both subtle localized pulmonary opacities and macro cardiomediastinal geometry.

### 2. Multimodal Linear Projection
- A projection layer ($W \in \mathbb{R}^{d_{swin} \times d_{t5}}$) bridges the modality gap by projecting the 1024-dimensional Swin visual feature vectors into the 768-dimensional language model embedding space.

### 3. Language Decoder (T5 Conditional Generator)
- **Model:** `t5-base`
- Uses encoder-decoder cross-attention to autoregressively synthesize clinical sentences, applying beam search to ensure syntactic coherence and medical terminology precision.

---

## 📊 Dataset & Model Weights

- **Dataset:** **CheXpert Plus** — a large-scale multimodal dataset consisting of chest radiographs paired with official clinical radiology reports.
- **Trained Model Weights:** The trained Swin-T5 weights (`swin-t5-model.pth`) map chest radiographs to standardized clinical impressions.
- **Simulation / Demo Mode:** Built-in `DEMO_MODE=true` allows full UI and application testing without downloading the multi-gigabyte weights.

---

## ✨ Features

- 🔍 **Vision-Language Report Generation:** Generates coherent radiology reports with structured *Findings* and *Impression*.
- 🖼️ **Radiology Inspection Viewport:**
  - Interactive cursor-centered magnifying glass with adjustable zoom factors (1.5x – 5.0x).
  - Radiographic Negative Inversion mode (essential for pulmonary nodule analysis).
  - High-contrast clinical enhancement.
- 📋 **Patient Metadata Extraction:** Automatically parses demographic data (view, age, gender, ethnicity) from CheXpert formatted filenames.
- 🌓 **Clinical Dark & Light Mode:** Optimized for reading rooms and standard desktop displays.
- 🖨️ **Export & Clipboard:** One-click copy to clipboard and print-formatted output.
- 🔒 **Local & Private:** Runs entirely locally with PyTorch without sending patient data to third parties.

---

## 🛠️ Technology Stack

| Component | Technology |
|---|---|
| **Backend** | Python 3.10+, Flask, PyTorch |
| **Vision-Language Model** | Swin Transformer, T5 (Hugging Face Transformers), Torchvision |
| **Frontend** | HTML5, CSS3, Vanilla JavaScript, Bootstrap 5, FontAwesome |
| **Deployment** | Windows Batch Script (`run.bat`), Gunicorn / Waitress |

---

## 🚀 Getting Started

### 1. Prerequisites
- Python 3.9 - 3.12 installed on your system.
- (Optional) NVIDIA GPU with CUDA for accelerated inference.

### 2. Automated Run (Windows)
Double-click `run.bat` or run in terminal:
```cmd
.\run.bat
```
This script automatically sets up the Python virtual environment (`venv`), installs dependencies, and launches the application.

### 3. Manual Setup

```powershell
# 1. Create and activate virtual environment
python -m venv venv
.\venv\Scripts\Activate.ps1

# 2. Install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# 3. Launch application
python app.py
```

Open your browser at:
```
http://127.0.0.1:5000
```

---

## ⚙️ Configuration (`.env`)

- **`DEMO_MODE=true`**: Lets you test the web application immediately with realistic simulated inference.
- **`DEMO_MODE=false`**: Loads the trained PyTorch weights from `swin-t5-model.pth` for live inference.
- **`MODEL_PATH=swin-t5-model.pth`**: Specifies the path to the model weights file.
