import os
import platform
import subprocess
import signal

def kill_port(port=5000):
    system = platform.system().lower()
    try:
        if system == 'windows':
            # Find PID listening on port
            cmd = f'netstat -ano | findstr :{port}'
            output = subprocess.check_output(cmd, shell=True).decode()
            pids = set()
            for line in output.strip().split('\n'):
                parts = line.split()
                if len(parts) >= 5 and 'LISTENING' in parts:
                    pid = parts[-1]
                    pids.add(pid)
            if not pids:
                print(f"No process is listening on port {port}.")
                return
            for pid in pids:
                try:
                    subprocess.run(f'taskkill /F /PID {pid}', shell=True, check=True)
                    print(f"Killed process PID {pid} on port {port}.")
                except subprocess.CalledProcessError as e:
                    print(f"Could not kill PID {pid}: {e}")
        else:
            result = subprocess.check_output(f'lsof -i :{port}', shell=True).decode()
            lines = result.strip().split('\n')
            for line in lines[1:]:
                parts = line.split()
                pid = int(parts[1])
                os.kill(pid, signal.SIGKILL)
                print(f'Killed PID {pid} using port {port}')
    except subprocess.CalledProcessError:
        print(f"No process is using port {port}.")
    except Exception as e:
        print(f"Error freeing port {port}: {e}")

if __name__ == '__main__':
    kill_port(5000)